package com.ctcgrooming.models;

import java.sql.*;
import java.time.LocalDateTime;
import com.ctcgrooming.database.DatabaseConnection;

/**
 * Admin Model - Represents an administrative user
 */
public class Admin {
    
    // ==================== PROPERTIES ====================
    private int adminID;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String phoneNumber;
    private String role;
    private boolean isActive;
    private LocalDateTime dateCreated;
    private LocalDateTime lastLogin;
    
    // ==================== CONSTRUCTORS ====================
    
    public Admin() {
    }
    
    public Admin(String firstName, String lastName, String email, String password, String role) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.role = role;
        this.isActive = true;
        this.dateCreated = LocalDateTime.now();
    }
    
    // ==================== GETTERS & SETTERS ====================
    
    public int getAdminID() {
        return adminID;
    }
    
    public void setAdminID(int adminID) {
        this.adminID = adminID;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
    
    public LocalDateTime getDateCreated() {
        return dateCreated;
    }
    
    public void setDateCreated(LocalDateTime dateCreated) {
        this.dateCreated = dateCreated;
    }
    
    public LocalDateTime getLastLogin() {
        return lastLogin;
    }
    
    public void setLastLogin(LocalDateTime lastLogin) {
        this.lastLogin = lastLogin;
    }
    
    // ==================== VALIDATION METHODS ====================
    
    public boolean isValidEmail() {
        if (email == null || email.isEmpty()) {
            return false;
        }
        return email.contains("@") && email.contains(".");
    }
    
    public boolean isValid() {
        return firstName != null && !firstName.isEmpty() &&
               lastName != null && !lastName.isEmpty() &&
               email != null && !email.isEmpty() &&
               password != null && !password.isEmpty() &&
               role != null && !role.isEmpty() &&
               isValidEmail();
    }
    
    // ==================== DATABASE METHODS ====================
    
    public boolean save() {
        if (!isValid()) {
            System.out.println("Invalid admin data");
            return false;
        }
        
        String sql = "INSERT INTO Admin (firstName, lastName, email, password, phoneNumber, " +
                     "role, isActive, dateCreated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, email);
            stmt.setString(4, password);  // Should be hashed!
            stmt.setString(5, phoneNumber);
            stmt.setString(6, role);
            stmt.setBoolean(7, isActive);
            stmt.setTimestamp(8, Timestamp.valueOf(LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.adminID = rs.getInt(1);
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.out.println("Error saving admin: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean update() {
        if (!isValid() || adminID == 0) {
            return false;
        }
        
        String sql = "UPDATE Admin SET firstName=?, lastName=?, email=?, phoneNumber=?, " +
                     "role=?, isActive=? WHERE adminID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, email);
            stmt.setString(4, phoneNumber);
            stmt.setString(5, role);
            stmt.setBoolean(6, isActive);
            stmt.setInt(7, adminID);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error updating admin: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean delete() {
        if (adminID == 0) {
            return false;
        }
        
        String sql = "DELETE FROM Admin WHERE adminID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, adminID);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error deleting admin: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public void updateLastLogin() {
        this.lastLogin = LocalDateTime.now();
        
        String sql = "UPDATE Admin SET lastLogin=? WHERE adminID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setTimestamp(1, Timestamp.valueOf(lastLogin));
            stmt.setInt(2, adminID);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println("Error updating last login: " + e.getMessage());
        }
    }
    
    // ==================== STATIC FINDER METHODS ====================
    
    public static Admin findByEmail(String email) {
        String sql = "SELECT * FROM Admin WHERE email=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractAdminFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding admin by email: " + e.getMessage());
        }
        
        return null;
    }
    
    public static Admin findByID(int adminID) {
        String sql = "SELECT * FROM Admin WHERE adminID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, adminID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractAdminFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding admin by ID: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Admin login method
     */
    public static Admin login(String email, String password) {
        Admin admin = findByEmail(email);
        
        if (admin != null && admin.isActive() && admin.getPassword().equals(password)) {
            admin.updateLastLogin();
            return admin;
        }
        
        return null;
    }
    
    // ==================== HELPER METHODS ====================
    
    private static Admin extractAdminFromResultSet(ResultSet rs) throws SQLException {
        Admin admin = new Admin();
        admin.setAdminID(rs.getInt("adminID"));
        admin.setFirstName(rs.getString("firstName"));
        admin.setLastName(rs.getString("lastName"));
        admin.setEmail(rs.getString("email"));
        admin.setPassword(rs.getString("password"));
        admin.setPhoneNumber(rs.getString("phoneNumber"));
        admin.setRole(rs.getString("role"));
        admin.setActive(rs.getBoolean("isActive"));
        
        Timestamp created = rs.getTimestamp("dateCreated");
        if (created != null) {
            admin.setDateCreated(created.toLocalDateTime());
        }
        
        Timestamp login = rs.getTimestamp("lastLogin");
        if (login != null) {
            admin.setLastLogin(login.toLocalDateTime());
        }
        
        return admin;
    }
    
    public String getFullName() {
        return firstName + " " + lastName;
    }
    
    @Override
    public String toString() {
        return "Admin{" +
                "adminID=" + adminID +
                ", name='" + getFullName() + '\'' +
                ", email='" + email + '\'' +
                ", role='" + role + '\'' +
                ", isActive=" + isActive +
                '}';
    }
}
