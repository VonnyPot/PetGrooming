package com.ctcgrooming.models;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import com.ctcgrooming.database.DatabaseConnection;

/**
 * Appointment Model - Represents a booked grooming appointment
 */
public class Appointment {
    
    // ==================== PROPERTIES ====================
    private int appointmentID;
    private int customerID;
    private int petID;
    private int serviceID;
    private int groomerID;
    private int availabilityID;
    private LocalDate appointmentDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private double totalPrice;
    private String status;  // "Pending", "Confirmed", "Completed", "Cancelled"
    private String specialRequests;
    private LocalDateTime dateBooked;
    private LocalDateTime dateModified;
    
    // ==================== CONSTRUCTORS ====================
    
    public Appointment() {
    }
    
    public Appointment(int customerID, int petID, int serviceID, int groomerID, 
                      int availabilityID, LocalDate appointmentDate, LocalTime startTime, 
                      LocalTime endTime, double totalPrice) {
        this.customerID = customerID;
        this.petID = petID;
        this.serviceID = serviceID;
        this.groomerID = groomerID;
        this.availabilityID = availabilityID;
        this.appointmentDate = appointmentDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.totalPrice = totalPrice;
        this.status = "Pending";
        this.dateBooked = LocalDateTime.now();
    }
    
    // ==================== GETTERS & SETTERS ====================
    
    public int getAppointmentID() {
        return appointmentID;
    }
    
    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }
    
    public int getCustomerID() {
        return customerID;
    }
    
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }
    
    public int getPetID() {
        return petID;
    }
    
    public void setPetID(int petID) {
        this.petID = petID;
    }
    
    public int getServiceID() {
        return serviceID;
    }
    
    public void setServiceID(int serviceID) {
        this.serviceID = serviceID;
    }
    
    public int getGroomerID() {
        return groomerID;
    }
    
    public void setGroomerID(int groomerID) {
        this.groomerID = groomerID;
    }
    
    public int getAvailabilityID() {
        return availabilityID;
    }
    
    public void setAvailabilityID(int availabilityID) {
        this.availabilityID = availabilityID;
    }
    
    public LocalDate getAppointmentDate() {
        return appointmentDate;
    }
    
    public void setAppointmentDate(LocalDate appointmentDate) {
        this.appointmentDate = appointmentDate;
    }
    
    public LocalTime getStartTime() {
        return startTime;
    }
    
    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }
    
    public LocalTime getEndTime() {
        return endTime;
    }
    
    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }
    
    public double getTotalPrice() {
        return totalPrice;
    }
    
    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getSpecialRequests() {
        return specialRequests;
    }
    
    public void setSpecialRequests(String specialRequests) {
        this.specialRequests = specialRequests;
    }
    
    public LocalDateTime getDateBooked() {
        return dateBooked;
    }
    
    public void setDateBooked(LocalDateTime dateBooked) {
        this.dateBooked = dateBooked;
    }
    
    public LocalDateTime getDateModified() {
        return dateModified;
    }
    
    public void setDateModified(LocalDateTime dateModified) {
        this.dateModified = dateModified;
    }
    
    // ==================== VALIDATION METHODS ====================
    
    public boolean isValidStatus() {
        return status != null && 
               (status.equals("Pending") || status.equals("Confirmed") || 
                status.equals("Completed") || status.equals("Cancelled"));
    }
    
    public boolean isValid() {
        return customerID > 0 &&
               petID > 0 &&
               serviceID > 0 &&
               groomerID > 0 &&
               availabilityID > 0 &&
               appointmentDate != null &&
               startTime != null &&
               endTime != null &&
               totalPrice > 0 &&
               isValidStatus();
    }
    
    // ==================== DATABASE METHODS ====================
    
    public boolean save() {
        if (!isValid()) {
            System.out.println("Invalid appointment data");
            return false;
        }
        
        String sql = "INSERT INTO Appointment (customerID, petID, serviceID, groomerID, " +
                     "availabilityID, appointmentDate, startTime, endTime, totalPrice, status, " +
                     "specialRequests, dateBooked) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, customerID);
            stmt.setInt(2, petID);
            stmt.setInt(3, serviceID);
            stmt.setInt(4, groomerID);
            stmt.setInt(5, availabilityID);
            stmt.setDate(6, Date.valueOf(appointmentDate));
            stmt.setTime(7, Time.valueOf(startTime));
            stmt.setTime(8, Time.valueOf(endTime));
            stmt.setDouble(9, totalPrice);
            stmt.setString(10, status);
            stmt.setString(11, specialRequests);
            stmt.setTimestamp(12, Timestamp.valueOf(LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.appointmentID = rs.getInt(1);
                }
                
                // Mark the availability slot as booked
                GroomerAvailability availability = GroomerAvailability.findByID(availabilityID);
                if (availability != null) {
                    availability.markAsBooked();
                }
                
                return true;
            }
            
        } catch (SQLException e) {
            System.out.println("Error saving appointment: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean update() {
        if (!isValid() || appointmentID == 0) {
            return false;
        }
        
        String sql = "UPDATE Appointment SET customerID=?, petID=?, serviceID=?, groomerID=?, " +
                     "appointmentDate=?, startTime=?, endTime=?, totalPrice=?, status=?, " +
                     "specialRequests=?, dateModified=? WHERE appointmentID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, customerID);
            stmt.setInt(2, petID);
            stmt.setInt(3, serviceID);
            stmt.setInt(4, groomerID);
            stmt.setDate(5, Date.valueOf(appointmentDate));
            stmt.setTime(6, Time.valueOf(startTime));
            stmt.setTime(7, Time.valueOf(endTime));
            stmt.setDouble(8, totalPrice);
            stmt.setString(9, status);
            stmt.setString(10, specialRequests);
            stmt.setTimestamp(11, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(12, appointmentID);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error updating appointment: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Cancel this appointment
     */
    public boolean cancel() {
        this.status = "Cancelled";
        
        if (update()) {
            // Free up the availability slot
            GroomerAvailability availability = GroomerAvailability.findByID(availabilityID);
            if (availability != null) {
                availability.markAsAvailable();
            }
            return true;
        }
        
        return false;
    }
    
    /**
     * Confirm this appointment
     */
    public boolean confirm() {
        this.status = "Confirmed";
        return update();
    }
    
    /**
     * Mark appointment as completed
     */
    public boolean complete() {
        this.status = "Completed";
        return update();
    }
    
    public boolean delete() {
        if (appointmentID == 0) {
            return false;
        }
        
        String sql = "DELETE FROM Appointment WHERE appointmentID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, appointmentID);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error deleting appointment: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // ==================== STATIC FINDER METHODS ====================
    
    public static Appointment findByID(int appointmentID) {
        String sql = "SELECT * FROM Appointment WHERE appointmentID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, appointmentID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractAppointmentFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding appointment: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Gets all appointments for a customer
     */
    public static List<Appointment> findByCustomerID(int customerID) {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT * FROM Appointment WHERE customerID=? ORDER BY appointmentDate, startTime";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, customerID);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                appointments.add(extractAppointmentFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding appointments by customer: " + e.getMessage());
        }
        
        return appointments;
    }
    
    /**
     * Gets all appointments for a specific date
     */
    public static List<Appointment> findByDate(LocalDate date) {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT * FROM Appointment WHERE appointmentDate=? ORDER BY startTime";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setDate(1, Date.valueOf(date));
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                appointments.add(extractAppointmentFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding appointments by date: " + e.getMessage());
        }
        
        return appointments;
    }
    
    /**
     * Gets upcoming appointments for a customer
     */
    public static List<Appointment> getUpcomingAppointments(int customerID) {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT * FROM Appointment WHERE customerID=? AND appointmentDate >= CURDATE() " +
                     "AND status NOT IN ('Cancelled', 'Completed') ORDER BY appointmentDate, startTime";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, customerID);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                appointments.add(extractAppointmentFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding upcoming appointments: " + e.getMessage());
        }
        
        return appointments;
    }
    
    // ==================== HELPER METHODS ====================
    
    private static Appointment extractAppointmentFromResultSet(ResultSet rs) throws SQLException {
        Appointment appointment = new Appointment();
        appointment.setAppointmentID(rs.getInt("appointmentID"));
        appointment.setCustomerID(rs.getInt("customerID"));
        appointment.setPetID(rs.getInt("petID"));
        appointment.setServiceID(rs.getInt("serviceID"));
        appointment.setGroomerID(rs.getInt("groomerID"));
        appointment.setAvailabilityID(rs.getInt("availabilityID"));
        appointment.setAppointmentDate(rs.getDate("appointmentDate").toLocalDate());
        appointment.setStartTime(rs.getTime("startTime").toLocalTime());
        appointment.setEndTime(rs.getTime("endTime").toLocalTime());
        appointment.setTotalPrice(rs.getDouble("totalPrice"));
        appointment.setStatus(rs.getString("status"));
        appointment.setSpecialRequests(rs.getString("specialRequests"));
        
        Timestamp booked = rs.getTimestamp("dateBooked");
        if (booked != null) {
            appointment.setDateBooked(booked.toLocalDateTime());
        }
        
        Timestamp modified = rs.getTimestamp("dateModified");
        if (modified != null) {
            appointment.setDateModified(modified.toLocalDateTime());
        }
        
        return appointment;
    }
    
    @Override
    public String toString() {
        return "Appointment{" +
                "appointmentID=" + appointmentID +
                ", date=" + appointmentDate +
                ", time=" + startTime + "-" + endTime +
                ", status='" + status + '\'' +
                ", totalPrice=$" + totalPrice +
                '}';
    }
}
