package com.ctcgrooming.models;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import com.ctcgrooming.database.DatabaseConnection;

/**
 * CartItem Model - Represents an item in a customer's shopping cart
 */
public class CartItem {
    
    // ==================== PROPERTIES ====================
    private int cartItemID;
    private int cartID;
    private int petID;
    private int serviceID;
    private int groomerID;
    private int availabilityID;
    private LocalDate selectedDate;
    private LocalTime selectedTime;
    private double price;
    private LocalDateTime dateAdded;
    
    // ==================== CONSTRUCTORS ====================
    
    public CartItem() {
    }
    
    public CartItem(int cartID, int petID, int serviceID, int groomerID, 
                   int availabilityID, LocalDate selectedDate, LocalTime selectedTime, double price) {
        this.cartID = cartID;
        this.petID = petID;
        this.serviceID = serviceID;
        this.groomerID = groomerID;
        this.availabilityID = availabilityID;
        this.selectedDate = selectedDate;
        this.selectedTime = selectedTime;
        this.price = price;
        this.dateAdded = LocalDateTime.now();
    }
    
    // ==================== GETTERS & SETTERS ====================
    
    public int getCartItemID() {
        return cartItemID;
    }
    
    public void setCartItemID(int cartItemID) {
        this.cartItemID = cartItemID;
    }
    
    public int getCartID() {
        return cartID;
    }
    
    public void setCartID(int cartID) {
        this.cartID = cartID;
    }
    
    public int getPetID() {
        return petID;
    }
    
    public void setPetID(int petID) {
        this.petID = petID;
    }
    
    public int getServiceID() {
        return serviceID;
    }
    
    public void setServiceID(int serviceID) {
        this.serviceID = serviceID;
    }
    
    public int getGroomerID() {
        return groomerID;
    }
    
    public void setGroomerID(int groomerID) {
        this.groomerID = groomerID;
    }
    
    public int getAvailabilityID() {
        return availabilityID;
    }
    
    public void setAvailabilityID(int availabilityID) {
        this.availabilityID = availabilityID;
    }
    
    public LocalDate getSelectedDate() {
        return selectedDate;
    }
    
    public void setSelectedDate(LocalDate selectedDate) {
        this.selectedDate = selectedDate;
    }
    
    public LocalTime getSelectedTime() {
        return selectedTime;
    }
    
    public void setSelectedTime(LocalTime selectedTime) {
        this.selectedTime = selectedTime;
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public LocalDateTime getDateAdded() {
        return dateAdded;
    }
    
    public void setDateAdded(LocalDateTime dateAdded) {
        this.dateAdded = dateAdded;
    }
    
    // ==================== VALIDATION METHODS ====================
    
    public boolean isValid() {
        return cartID > 0 &&
               petID > 0 &&
               serviceID > 0 &&
               groomerID > 0 &&
               availabilityID > 0 &&
               selectedDate != null &&
               selectedTime != null &&
               price > 0;
    }
    
    // ==================== DATABASE METHODS ====================
    
    public boolean save() {
        if (!isValid()) {
            System.out.println("Invalid cart item data");
            return false;
        }
        
        String sql = "INSERT INTO CartItem (cartID, petID, serviceID, groomerID, availabilityID, " +
                     "selectedDate, selectedTime, price, dateAdded) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, cartID);
            stmt.setInt(2, petID);
            stmt.setInt(3, serviceID);
            stmt.setInt(4, groomerID);
            stmt.setInt(5, availabilityID);
            stmt.setDate(6, Date.valueOf(selectedDate));
            stmt.setTime(7, Time.valueOf(selectedTime));
            stmt.setDouble(8, price);
            stmt.setTimestamp(9, Timestamp.valueOf(LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.cartItemID = rs.getInt(1);
                }
                
                // Update the cart's modified date
                ShoppingCart cart = ShoppingCart.findByID(cartID);
                if (cart != null) {
                    cart.update();
                }
                
                return true;
            }
            
        } catch (SQLException e) {
            System.out.println("Error saving cart item: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean update() {
        if (!isValid() || cartItemID == 0) {
            return false;
        }
        
        String sql = "UPDATE CartItem SET petID=?, serviceID=?, groomerID=?, availabilityID=?, " +
                     "selectedDate=?, selectedTime=?, price=? WHERE cartItemID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, petID);
            stmt.setInt(2, serviceID);
            stmt.setInt(3, groomerID);
            stmt.setInt(4, availabilityID);
            stmt.setDate(5, Date.valueOf(selectedDate));
            stmt.setTime(6, Time.valueOf(selectedTime));
            stmt.setDouble(7, price);
            stmt.setInt(8, cartItemID);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error updating cart item: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean delete() {
        if (cartItemID == 0) {
            return false;
        }
        
        String sql = "DELETE FROM CartItem WHERE cartItemID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, cartItemID);
            
            boolean success = stmt.executeUpdate() > 0;
            
            if (success) {
                // Update the cart's modified date
                ShoppingCart cart = ShoppingCart.findByID(cartID);
                if (cart != null) {
                    cart.update();
                }
            }
            
            return success;
            
        } catch (SQLException e) {
            System.out.println("Error deleting cart item: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // ==================== STATIC FINDER METHODS ====================
    
    public static CartItem findByID(int cartItemID) {
        String sql = "SELECT * FROM CartItem WHERE cartItemID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, cartItemID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractCartItemFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding cart item: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Gets all items in a cart
     */
    public static List<CartItem> findByCartID(int cartID) {
        List<CartItem> items = new ArrayList<>();
        String sql = "SELECT * FROM CartItem WHERE cartID=? ORDER BY dateAdded";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, cartID);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                items.add(extractCartItemFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding cart items: " + e.getMessage());
        }
        
        return items;
    }
    
    /**
     * Gets the total price of all items in a cart
     */
    public static double getCartTotal(int cartID) {
        String sql = "SELECT SUM(price) as total FROM CartItem WHERE cartID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, cartID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
            
        } catch (SQLException e) {
            System.out.println("Error calculating cart total: " + e.getMessage());
        }
        
        return 0.0;
    }
    
    /**
     * Converts cart item to appointment
     * Used during checkout
     */
    public Appointment convertToAppointment(int customerID) {
        // Get the service to calculate end time
        Service service = Service.findByID(serviceID);
        if (service == null) {
            return null;
        }
        
        // Calculate end time
        LocalTime endTime = selectedTime.plusMinutes(service.getDuration());
        
        Appointment appointment = new Appointment(
            customerID,
            petID,
            serviceID,
            groomerID,
            availabilityID,
            selectedDate,
            selectedTime,
            endTime,
            price
        );
        
        return appointment;
    }
    
    // ==================== HELPER METHODS ====================
    
    private static CartItem extractCartItemFromResultSet(ResultSet rs) throws SQLException {
        CartItem item = new CartItem();
        item.setCartItemID(rs.getInt("cartItemID"));
        item.setCartID(rs.getInt("cartID"));
        item.setPetID(rs.getInt("petID"));
        item.setServiceID(rs.getInt("serviceID"));
        item.setGroomerID(rs.getInt("groomerID"));
        item.setAvailabilityID(rs.getInt("availabilityID"));
        item.setSelectedDate(rs.getDate("selectedDate").toLocalDate());
        item.setSelectedTime(rs.getTime("selectedTime").toLocalTime());
        item.setPrice(rs.getDouble("price"));
        
        Timestamp added = rs.getTimestamp("dateAdded");
        if (added != null) {
            item.setDateAdded(added.toLocalDateTime());
        }
        
        return item;
    }
    
    @Override
    public String toString() {
        return "CartItem{" +
                "cartItemID=" + cartItemID +
                ", serviceID=" + serviceID +
                ", petID=" + petID +
                ", date=" + selectedDate +
                ", time=" + selectedTime +
                ", price=$" + price +
                '}';
    }
}
