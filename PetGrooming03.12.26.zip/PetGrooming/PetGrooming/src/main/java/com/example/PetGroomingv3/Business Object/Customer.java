package com.ctcgrooming.models;

import java.sql.*;
import java.time.LocalDateTime;
import com.ctcgrooming.database.DatabaseConnection;

/**
 * Customer Model - Represents a customer in the pet grooming system
 * 
 * This class maps to the Customer table in the database and provides
 * methods to interact with customer data.
 */
public class Customer {
    
    // ==================== PROPERTIES ====================
    private int customerID;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String phoneNumber;
    private String address;
    private String city;
    private String state;
    private String zipCode;
    private LocalDateTime dateCreated;
    private LocalDateTime lastLogin;
    
    // ==================== CONSTRUCTORS ====================
    
    /**
     * Empty constructor (useful for creating new customers)
     */
    public Customer() {
    }
    
    /**
     * Constructor for creating a new customer (without ID)
     */
    public Customer(String firstName, String lastName, String email, String password, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.dateCreated = LocalDateTime.now();
    }
    
    /**
     * Full constructor (used when loading from database)
     */
    public Customer(int customerID, String firstName, String lastName, String email, 
                   String password, String phoneNumber, String address, String city, 
                   String state, String zipCode, LocalDateTime dateCreated, LocalDateTime lastLogin) {
        this.customerID = customerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
        this.dateCreated = dateCreated;
        this.lastLogin = lastLogin;
    }
    
    // ==================== GETTERS & SETTERS ====================
    
    public int getCustomerID() {
        return customerID;
    }
    
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getCity() {
        return city;
    }
    
    public void setCity(String city) {
        this.city = city;
    }
    
    public String getState() {
        return state;
    }
    
    public void setState(String state) {
        this.state = state;
    }
    
    public String getZipCode() {
        return zipCode;
    }
    
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
    
    public LocalDateTime getDateCreated() {
        return dateCreated;
    }
    
    public void setDateCreated(LocalDateTime dateCreated) {
        this.dateCreated = dateCreated;
    }
    
    public LocalDateTime getLastLogin() {
        return lastLogin;
    }
    
    public void setLastLogin(LocalDateTime lastLogin) {
        this.lastLogin = lastLogin;
    }
    
    // ==================== VALIDATION METHODS ====================
    
    /**
     * Validates if the email format is correct
     * @return true if email is valid, false otherwise
     */
    public boolean isValidEmail() {
        if (email == null || email.isEmpty()) {
            return false;
        }
        // Simple email validation (contains @ and .)
        return email.contains("@") && email.contains(".");
    }
    
    /**
     * Validates if all required fields are filled
     * @return true if valid, false otherwise
     */
    public boolean isValid() {
        return firstName != null && !firstName.isEmpty() &&
               lastName != null && !lastName.isEmpty() &&
               email != null && !email.isEmpty() &&
               password != null && !password.isEmpty() &&
               phoneNumber != null && !phoneNumber.isEmpty() &&
               isValidEmail();
    }
    
    // ==================== DATABASE METHODS ====================
    
    /**
     * Saves a new customer to the database
     * @return true if successful, false otherwise
     */
    public boolean save() {
        if (!isValid()) {
            System.out.println("Invalid customer data");
            return false;
        }
        
        String sql = "INSERT INTO Customer (firstName, lastName, email, password, phoneNumber, " +
                     "address, city, state, zipCode, dateCreated) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, email);
            stmt.setString(4, password); // NOTE: Should be hashed before saving!
            stmt.setString(5, phoneNumber);
            stmt.setString(6, address);
            stmt.setString(7, city);
            stmt.setString(8, state);
            stmt.setString(9, zipCode);
            stmt.setTimestamp(10, Timestamp.valueOf(LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the auto-generated ID
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.customerID = rs.getInt(1);
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.out.println("Error saving customer: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Updates existing customer information in the database
     * @return true if successful, false otherwise
     */
    public boolean update() {
        if (!isValid() || customerID == 0) {
            return false;
        }
        
        String sql = "UPDATE Customer SET firstName=?, lastName=?, email=?, phoneNumber=?, " +
                     "address=?, city=?, state=?, zipCode=? WHERE customerID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, email);
            stmt.setString(4, phoneNumber);
            stmt.setString(5, address);
            stmt.setString(6, city);
            stmt.setString(7, state);
            stmt.setString(8, zipCode);
            stmt.setInt(9, customerID);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error updating customer: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Deletes this customer from the database
     * @return true if successful, false otherwise
     */
    public boolean delete() {
        if (customerID == 0) {
            return false;
        }
        
        String sql = "DELETE FROM Customer WHERE customerID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, customerID);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error deleting customer: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Updates the last login timestamp
     */
    public void updateLastLogin() {
        this.lastLogin = LocalDateTime.now();
        
        String sql = "UPDATE Customer SET lastLogin=? WHERE customerID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setTimestamp(1, Timestamp.valueOf(lastLogin));
            stmt.setInt(2, customerID);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println("Error updating last login: " + e.getMessage());
        }
    }
    
    // ==================== STATIC FINDER METHODS ====================
    
    /**
     * Finds a customer by their email address
     * @param email the email to search for
     * @return Customer object if found, null otherwise
     */
    public static Customer findByEmail(String email) {
        String sql = "SELECT * FROM Customer WHERE email=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractCustomerFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding customer by email: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Finds a customer by their ID
     * @param customerID the ID to search for
     * @return Customer object if found, null otherwise
     */
    public static Customer findByID(int customerID) {
        String sql = "SELECT * FROM Customer WHERE customerID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, customerID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractCustomerFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding customer by ID: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Validates login credentials
     * @param email customer's email
     * @param password customer's password (should be hashed)
     * @return Customer object if credentials are valid, null otherwise
     */
    public static Customer login(String email, String password) {
        Customer customer = findByEmail(email);
        
        if (customer != null && customer.getPassword().equals(password)) {
            customer.updateLastLogin();
            return customer;
        }
        
        return null;
    }
    
    // ==================== HELPER METHODS ====================
    
    /**
     * Extracts a Customer object from a ResultSet
     * @param rs the ResultSet containing customer data
     * @return Customer object
     * @throws SQLException if there's an error reading from ResultSet
     */
    private static Customer extractCustomerFromResultSet(ResultSet rs) throws SQLException {
        Customer customer = new Customer();
        customer.setCustomerID(rs.getInt("customerID"));
        customer.setFirstName(rs.getString("firstName"));
        customer.setLastName(rs.getString("lastName"));
        customer.setEmail(rs.getString("email"));
        customer.setPassword(rs.getString("password"));
        customer.setPhoneNumber(rs.getString("phoneNumber"));
        customer.setAddress(rs.getString("address"));
        customer.setCity(rs.getString("city"));
        customer.setState(rs.getString("state"));
        customer.setZipCode(rs.getString("zipCode"));
        
        Timestamp created = rs.getTimestamp("dateCreated");
        if (created != null) {
            customer.setDateCreated(created.toLocalDateTime());
        }
        
        Timestamp login = rs.getTimestamp("lastLogin");
        if (login != null) {
            customer.setLastLogin(login.toLocalDateTime());
        }
        
        return customer;
    }
    
    // ==================== OVERRIDE METHODS ====================
    
    @Override
    public String toString() {
        return "Customer{" +
                "customerID=" + customerID +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
