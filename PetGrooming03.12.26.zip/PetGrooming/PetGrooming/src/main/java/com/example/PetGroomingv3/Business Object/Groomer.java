package com.ctcgrooming.models;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import com.ctcgrooming.database.DatabaseConnection;

/**
 * Groomer Model - Represents a pet groomer employee
 */
public class Groomer {
    
    // ==================== PROPERTIES ====================
    private int groomerID;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String specialization;
    private boolean isActive;
    private LocalDateTime dateHired;
    
    // ==================== CONSTRUCTORS ====================
    
    public Groomer() {
    }
    
    public Groomer(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.isActive = true;
        this.dateHired = LocalDateTime.now();
    }
    
    public Groomer(String firstName, String lastName, String email, String phoneNumber, String specialization) {
        this(firstName, lastName);
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.specialization = specialization;
    }
    
    // ==================== GETTERS & SETTERS ====================
    
    public int getGroomerID() {
        return groomerID;
    }
    
    public void setGroomerID(int groomerID) {
        this.groomerID = groomerID;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String getSpecialization() {
        return specialization;
    }
    
    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
    
    public LocalDateTime getDateHired() {
        return dateHired;
    }
    
    public void setDateHired(LocalDateTime dateHired) {
        this.dateHired = dateHired;
    }
    
    // ==================== VALIDATION METHODS ====================
    
    public boolean isValid() {
        return firstName != null && !firstName.isEmpty() &&
               lastName != null && !lastName.isEmpty();
    }
    
    // ==================== DATABASE METHODS ====================
    
    public boolean save() {
        if (!isValid()) {
            System.out.println("Invalid groomer data");
            return false;
        }
        
        String sql = "INSERT INTO Groomer (firstName, lastName, email, phoneNumber, " +
                     "specialization, isActive, dateHired) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, email);
            stmt.setString(4, phoneNumber);
            stmt.setString(5, specialization);
            stmt.setBoolean(6, isActive);
            stmt.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.groomerID = rs.getInt(1);
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.out.println("Error saving groomer: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean update() {
        if (!isValid() || groomerID == 0) {
            return false;
        }
        
        String sql = "UPDATE Groomer SET firstName=?, lastName=?, email=?, phoneNumber=?, " +
                     "specialization=?, isActive=? WHERE groomerID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, email);
            stmt.setString(4, phoneNumber);
            stmt.setString(5, specialization);
            stmt.setBoolean(6, isActive);
            stmt.setInt(7, groomerID);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error updating groomer: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean delete() {
        if (groomerID == 0) {
            return false;
        }
        
        String sql = "DELETE FROM Groomer WHERE groomerID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, groomerID);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error deleting groomer: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // ==================== STATIC FINDER METHODS ====================
    
    public static Groomer findByID(int groomerID) {
        String sql = "SELECT * FROM Groomer WHERE groomerID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, groomerID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractGroomerFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding groomer: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Gets all active groomers
     */
    public static List<Groomer> getAllActiveGroomers() {
        List<Groomer> groomers = new ArrayList<>();
        String sql = "SELECT * FROM Groomer WHERE isActive=true ORDER BY firstName, lastName";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                groomers.add(extractGroomerFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error getting groomers: " + e.getMessage());
        }
        
        return groomers;
    }
    
    /**
     * Gets all groomers (active and inactive)
     */
    public static List<Groomer> getAllGroomers() {
        List<Groomer> groomers = new ArrayList<>();
        String sql = "SELECT * FROM Groomer ORDER BY firstName, lastName";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                groomers.add(extractGroomerFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error getting all groomers: " + e.getMessage());
        }
        
        return groomers;
    }
    
    // ==================== HELPER METHODS ====================
    
    private static Groomer extractGroomerFromResultSet(ResultSet rs) throws SQLException {
        Groomer groomer = new Groomer();
        groomer.setGroomerID(rs.getInt("groomerID"));
        groomer.setFirstName(rs.getString("firstName"));
        groomer.setLastName(rs.getString("lastName"));
        groomer.setEmail(rs.getString("email"));
        groomer.setPhoneNumber(rs.getString("phoneNumber"));
        groomer.setSpecialization(rs.getString("specialization"));
        groomer.setActive(rs.getBoolean("isActive"));
        
        Timestamp hired = rs.getTimestamp("dateHired");
        if (hired != null) {
            groomer.setDateHired(hired.toLocalDateTime());
        }
        
        return groomer;
    }
    
    public String getFullName() {
        return firstName + " " + lastName;
    }
    
    @Override
    public String toString() {
        return "Groomer{" +
                "groomerID=" + groomerID +
                ", name='" + getFullName() + '\'' +
                ", specialization='" + specialization + '\'' +
                ", isActive=" + isActive +
                '}';
    }
}
