package com.ctcgrooming.models;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import com.ctcgrooming.database.DatabaseConnection;

/**
 * GroomerAvailability Model - Represents time slots when groomers are available
 */
public class GroomerAvailability {
    
    // ==================== PROPERTIES ====================
    private int availabilityID;
    private int groomerID;
    private LocalDate availableDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private boolean isBooked;
    private int createdBy;          // Admin who created this slot
    private LocalDateTime dateCreated;
    
    // ==================== CONSTRUCTORS ====================
    
    public GroomerAvailability() {
    }
    
    public GroomerAvailability(int groomerID, LocalDate availableDate, 
                              LocalTime startTime, LocalTime endTime, int createdBy) {
        this.groomerID = groomerID;
        this.availableDate = availableDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.createdBy = createdBy;
        this.isBooked = false;
        this.dateCreated = LocalDateTime.now();
    }
    
    // ==================== GETTERS & SETTERS ====================
    
    public int getAvailabilityID() {
        return availabilityID;
    }
    
    public void setAvailabilityID(int availabilityID) {
        this.availabilityID = availabilityID;
    }
    
    public int getGroomerID() {
        return groomerID;
    }
    
    public void setGroomerID(int groomerID) {
        this.groomerID = groomerID;
    }
    
    public LocalDate getAvailableDate() {
        return availableDate;
    }
    
    public void setAvailableDate(LocalDate availableDate) {
        this.availableDate = availableDate;
    }
    
    public LocalTime getStartTime() {
        return startTime;
    }
    
    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }
    
    public LocalTime getEndTime() {
        return endTime;
    }
    
    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }
    
    public boolean isBooked() {
        return isBooked;
    }
    
    public void setBooked(boolean booked) {
        isBooked = booked;
    }
    
    public int getCreatedBy() {
        return createdBy;
    }
    
    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }
    
    public LocalDateTime getDateCreated() {
        return dateCreated;
    }
    
    public void setDateCreated(LocalDateTime dateCreated) {
        this.dateCreated = dateCreated;
    }
    
    // ==================== VALIDATION METHODS ====================
    
    public boolean isValid() {
        return groomerID > 0 &&
               availableDate != null &&
               startTime != null &&
               endTime != null &&
               createdBy > 0 &&
               endTime.isAfter(startTime);
    }
    
    // ==================== DATABASE METHODS ====================
    
    public boolean save() {
        if (!isValid()) {
            System.out.println("Invalid availability data");
            return false;
        }
        
        String sql = "INSERT INTO GroomerAvailability (groomerID, availableDate, startTime, " +
                     "endTime, isBooked, createdBy, dateCreated) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, groomerID);
            stmt.setDate(2, Date.valueOf(availableDate));
            stmt.setTime(3, Time.valueOf(startTime));
            stmt.setTime(4, Time.valueOf(endTime));
            stmt.setBoolean(5, isBooked);
            stmt.setInt(6, createdBy);
            stmt.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.availabilityID = rs.getInt(1);
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.out.println("Error saving availability: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean update() {
        if (!isValid() || availabilityID == 0) {
            return false;
        }
        
        String sql = "UPDATE GroomerAvailability SET groomerID=?, availableDate=?, startTime=?, " +
                     "endTime=?, isBooked=? WHERE availabilityID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, groomerID);
            stmt.setDate(2, Date.valueOf(availableDate));
            stmt.setTime(3, Time.valueOf(startTime));
            stmt.setTime(4, Time.valueOf(endTime));
            stmt.setBoolean(5, isBooked);
            stmt.setInt(6, availabilityID);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error updating availability: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Mark this slot as booked
     */
    public boolean markAsBooked() {
        this.isBooked = true;
        return update();
    }
    
    /**
     * Mark this slot as available (unbook)
     */
    public boolean markAsAvailable() {
        this.isBooked = false;
        return update();
    }
    
    public boolean delete() {
        if (availabilityID == 0) {
            return false;
        }
        
        String sql = "DELETE FROM GroomerAvailability WHERE availabilityID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, availabilityID);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error deleting availability: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // ==================== STATIC FINDER METHODS ====================
    
    public static GroomerAvailability findByID(int availabilityID) {
        String sql = "SELECT * FROM GroomerAvailability WHERE availabilityID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, availabilityID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractAvailabilityFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding availability: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Gets available (not booked) slots for a specific date
     */
    public static List<GroomerAvailability> getAvailableSlotsByDate(LocalDate date) {
        List<GroomerAvailability> slots = new ArrayList<>();
        String sql = "SELECT * FROM GroomerAvailability WHERE availableDate=? AND isBooked=false " +
                     "ORDER BY startTime";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setDate(1, Date.valueOf(date));
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                slots.add(extractAvailabilityFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error getting available slots: " + e.getMessage());
        }
        
        return slots;
    }
    
    /**
     * Gets all slots for a specific groomer on a specific date
     */
    public static List<GroomerAvailability> getSlotsByGroomerAndDate(int groomerID, LocalDate date) {
        List<GroomerAvailability> slots = new ArrayList<>();
        String sql = "SELECT * FROM GroomerAvailability WHERE groomerID=? AND availableDate=? " +
                     "ORDER BY startTime";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, groomerID);
            stmt.setDate(2, Date.valueOf(date));
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                slots.add(extractAvailabilityFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error getting groomer slots: " + e.getMessage());
        }
        
        return slots;
    }
    
    /**
     * Gets all available slots for a specific groomer
     */
    public static List<GroomerAvailability> getAvailableSlotsByGroomer(int groomerID) {
        List<GroomerAvailability> slots = new ArrayList<>();
        String sql = "SELECT * FROM GroomerAvailability WHERE groomerID=? AND isBooked=false " +
                     "ORDER BY availableDate, startTime";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, groomerID);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                slots.add(extractAvailabilityFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error getting groomer available slots: " + e.getMessage());
        }
        
        return slots;
    }
    
    // ==================== HELPER METHODS ====================
    
    private static GroomerAvailability extractAvailabilityFromResultSet(ResultSet rs) throws SQLException {
        GroomerAvailability availability = new GroomerAvailability();
        availability.setAvailabilityID(rs.getInt("availabilityID"));
        availability.setGroomerID(rs.getInt("groomerID"));
        availability.setAvailableDate(rs.getDate("availableDate").toLocalDate());
        availability.setStartTime(rs.getTime("startTime").toLocalTime());
        availability.setEndTime(rs.getTime("endTime").toLocalTime());
        availability.setBooked(rs.getBoolean("isBooked"));
        availability.setCreatedBy(rs.getInt("createdBy"));
        
        Timestamp created = rs.getTimestamp("dateCreated");
        if (created != null) {
            availability.setDateCreated(created.toLocalDateTime());
        }
        
        return availability;
    }
    
    @Override
    public String toString() {
        return "GroomerAvailability{" +
                "availabilityID=" + availabilityID +
                ", groomerID=" + groomerID +
                ", date=" + availableDate +
                ", time=" + startTime + "-" + endTime +
                ", isBooked=" + isBooked +
                '}';
    }
}
