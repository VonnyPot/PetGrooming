package com.ctcgrooming.models;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import com.ctcgrooming.database.DatabaseConnection;

/**
 * Pet Model - Represents a pet (dog or cat) in the system
 */
public class Pet {
    
    // ==================== PROPERTIES ====================
    private int petID;
    private int customerID;
    private String petName;
    private String petType;  // "Dog" or "Cat"
    private String breed;
    private int age;
    private double weight;
    private String specialNotes;
    private LocalDateTime dateAdded;
    
    // ==================== CONSTRUCTORS ====================
    
    public Pet() {
    }
    
    public Pet(int customerID, String petName, String petType) {
        this.customerID = customerID;
        this.petName = petName;
        this.petType = petType;
        this.dateAdded = LocalDateTime.now();
    }
    
    public Pet(int customerID, String petName, String petType, String breed, int age, double weight) {
        this(customerID, petName, petType);
        this.breed = breed;
        this.age = age;
        this.weight = weight;
    }
    
    // ==================== GETTERS & SETTERS ====================
    
    public int getPetID() {
        return petID;
    }
    
    public void setPetID(int petID) {
        this.petID = petID;
    }
    
    public int getCustomerID() {
        return customerID;
    }
    
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }
    
    public String getPetName() {
        return petName;
    }
    
    public void setPetName(String petName) {
        this.petName = petName;
    }
    
    public String getPetType() {
        return petType;
    }
    
    public void setPetType(String petType) {
        this.petType = petType;
    }
    
    public String getBreed() {
        return breed;
    }
    
    public void setBreed(String breed) {
        this.breed = breed;
    }
    
    public int getAge() {
        return age;
    }
    
    public void setAge(int age) {
        this.age = age;
    }
    
    public double getWeight() {
        return weight;
    }
    
    public void setWeight(double weight) {
        this.weight = weight;
    }
    
    public String getSpecialNotes() {
        return specialNotes;
    }
    
    public void setSpecialNotes(String specialNotes) {
        this.specialNotes = specialNotes;
    }
    
    public LocalDateTime getDateAdded() {
        return dateAdded;
    }
    
    public void setDateAdded(LocalDateTime dateAdded) {
        this.dateAdded = dateAdded;
    }
    
    // ==================== VALIDATION METHODS ====================
    
    public boolean isValidPetType() {
        return petType != null && (petType.equals("Dog") || petType.equals("Cat"));
    }
    
    public boolean isValid() {
        return customerID > 0 &&
               petName != null && !petName.isEmpty() &&
               isValidPetType();
    }
    
    // ==================== DATABASE METHODS ====================
    
    /**
     * Saves a new pet to the database
     */
    public boolean save() {
        if (!isValid()) {
            System.out.println("Invalid pet data");
            return false;
        }
        
        String sql = "INSERT INTO Pet (customerID, petName, petType, breed, age, weight, " +
                     "specialNotes, dateAdded) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, customerID);
            stmt.setString(2, petName);
            stmt.setString(3, petType);
            stmt.setString(4, breed);
            stmt.setInt(5, age);
            stmt.setDouble(6, weight);
            stmt.setString(7, specialNotes);
            stmt.setTimestamp(8, Timestamp.valueOf(LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.petID = rs.getInt(1);
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.out.println("Error saving pet: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Updates existing pet information
     */
    public boolean update() {
        if (!isValid() || petID == 0) {
            return false;
        }
        
        String sql = "UPDATE Pet SET petName=?, petType=?, breed=?, age=?, weight=?, " +
                     "specialNotes=? WHERE petID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, petName);
            stmt.setString(2, petType);
            stmt.setString(3, breed);
            stmt.setInt(4, age);
            stmt.setDouble(5, weight);
            stmt.setString(6, specialNotes);
            stmt.setInt(7, petID);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error updating pet: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Deletes this pet from the database
     */
    public boolean delete() {
        if (petID == 0) {
            return false;
        }
        
        String sql = "DELETE FROM Pet WHERE petID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, petID);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error deleting pet: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // ==================== STATIC FINDER METHODS ====================
    
    /**
     * Finds a pet by ID
     */
    public static Pet findByID(int petID) {
        String sql = "SELECT * FROM Pet WHERE petID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, petID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractPetFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding pet: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Gets all pets for a specific customer
     */
    public static List<Pet> findByCustomerID(int customerID) {
        List<Pet> pets = new ArrayList<>();
        String sql = "SELECT * FROM Pet WHERE customerID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, customerID);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                pets.add(extractPetFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding pets for customer: " + e.getMessage());
        }
        
        return pets;
    }
    
    // ==================== HELPER METHODS ====================
    
    private static Pet extractPetFromResultSet(ResultSet rs) throws SQLException {
        Pet pet = new Pet();
        pet.setPetID(rs.getInt("petID"));
        pet.setCustomerID(rs.getInt("customerID"));
        pet.setPetName(rs.getString("petName"));
        pet.setPetType(rs.getString("petType"));
        pet.setBreed(rs.getString("breed"));
        pet.setAge(rs.getInt("age"));
        pet.setWeight(rs.getDouble("weight"));
        pet.setSpecialNotes(rs.getString("specialNotes"));
        
        Timestamp added = rs.getTimestamp("dateAdded");
        if (added != null) {
            pet.setDateAdded(added.toLocalDateTime());
        }
        
        return pet;
    }
    
    @Override
    public String toString() {
        return "Pet{" +
                "petID=" + petID +
                ", petName='" + petName + '\'' +
                ", petType='" + petType + '\'' +
                ", breed='" + breed + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                '}';
    }
}
