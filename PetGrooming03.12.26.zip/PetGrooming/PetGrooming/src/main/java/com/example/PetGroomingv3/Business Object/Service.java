package com.ctcgrooming.models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.ctcgrooming.database.DatabaseConnection;

/**
 * Service Model - Represents a grooming service offered by CTC Pet Grooming
 */
public class Service {
    
    // ==================== PROPERTIES ====================
    private int serviceID;
    private String serviceName;
    private String description;
    private int duration;           // in minutes
    private double basePrice;
    private String petTypeApplicable;  // "Dog", "Cat", or "Both"
    private boolean isActive;
    
    // ==================== CONSTRUCTORS ====================
    
    public Service() {
    }
    
    public Service(String serviceName, int duration, double basePrice, String petTypeApplicable) {
        this.serviceName = serviceName;
        this.duration = duration;
        this.basePrice = basePrice;
        this.petTypeApplicable = petTypeApplicable;
        this.isActive = true;
    }
    
    // ==================== GETTERS & SETTERS ====================
    
    public int getServiceID() {
        return serviceID;
    }
    
    public void setServiceID(int serviceID) {
        this.serviceID = serviceID;
    }
    
    public String getServiceName() {
        return serviceName;
    }
    
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public int getDuration() {
        return duration;
    }
    
    public void setDuration(int duration) {
        this.duration = duration;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
    
    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }
    
    public String getPetTypeApplicable() {
        return petTypeApplicable;
    }
    
    public void setPetTypeApplicable(String petTypeApplicable) {
        this.petTypeApplicable = petTypeApplicable;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
    
    // ==================== VALIDATION METHODS ====================
    
    public boolean isValidPetType() {
        return petTypeApplicable != null && 
               (petTypeApplicable.equals("Dog") || 
                petTypeApplicable.equals("Cat") || 
                petTypeApplicable.equals("Both"));
    }
    
    public boolean isValid() {
        return serviceName != null && !serviceName.isEmpty() &&
               duration > 0 &&
               basePrice > 0 &&
               isValidPetType();
    }
    
    // ==================== DATABASE METHODS ====================
    
    public boolean save() {
        if (!isValid()) {
            System.out.println("Invalid service data");
            return false;
        }
        
        String sql = "INSERT INTO Service (serviceName, description, duration, basePrice, " +
                     "petTypeApplicable, isActive) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, serviceName);
            stmt.setString(2, description);
            stmt.setInt(3, duration);
            stmt.setDouble(4, basePrice);
            stmt.setString(5, petTypeApplicable);
            stmt.setBoolean(6, isActive);
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.serviceID = rs.getInt(1);
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.out.println("Error saving service: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean update() {
        if (!isValid() || serviceID == 0) {
            return false;
        }
        
        String sql = "UPDATE Service SET serviceName=?, description=?, duration=?, " +
                     "basePrice=?, petTypeApplicable=?, isActive=? WHERE serviceID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, serviceName);
            stmt.setString(2, description);
            stmt.setInt(3, duration);
            stmt.setDouble(4, basePrice);
            stmt.setString(5, petTypeApplicable);
            stmt.setBoolean(6, isActive);
            stmt.setInt(7, serviceID);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error updating service: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean delete() {
        if (serviceID == 0) {
            return false;
        }
        
        String sql = "DELETE FROM Service WHERE serviceID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, serviceID);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error deleting service: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // ==================== STATIC FINDER METHODS ====================
    
    public static Service findByID(int serviceID) {
        String sql = "SELECT * FROM Service WHERE serviceID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, serviceID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractServiceFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding service: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Gets all active services
     */
    public static List<Service> getAllActiveServices() {
        List<Service> services = new ArrayList<>();
        String sql = "SELECT * FROM Service WHERE isActive=true ORDER BY serviceName";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                services.add(extractServiceFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error getting services: " + e.getMessage());
        }
        
        return services;
    }
    
    /**
     * Gets services for a specific pet type
     */
    public static List<Service> getServicesByPetType(String petType) {
        List<Service> services = new ArrayList<>();
        String sql = "SELECT * FROM Service WHERE isActive=true AND " +
                     "(petTypeApplicable=? OR petTypeApplicable='Both') ORDER BY serviceName";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, petType);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                services.add(extractServiceFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.out.println("Error getting services by pet type: " + e.getMessage());
        }
        
        return services;
    }
    
    // ==================== HELPER METHODS ====================
    
    private static Service extractServiceFromResultSet(ResultSet rs) throws SQLException {
        Service service = new Service();
        service.setServiceID(rs.getInt("serviceID"));
        service.setServiceName(rs.getString("serviceName"));
        service.setDescription(rs.getString("description"));
        service.setDuration(rs.getInt("duration"));
        service.setBasePrice(rs.getDouble("basePrice"));
        service.setPetTypeApplicable(rs.getString("petTypeApplicable"));
        service.setActive(rs.getBoolean("isActive"));
        
        return service;
    }
    
    @Override
    public String toString() {
        return "Service{" +
                "serviceID=" + serviceID +
                ", serviceName='" + serviceName + '\'' +
                ", duration=" + duration + " mins" +
                ", basePrice=$" + basePrice +
                ", petType='" + petTypeApplicable + '\'' +
                '}';
    }
}
