package com.ctcgrooming.models;

import java.sql.*;
import java.time.LocalDateTime;
import com.ctcgrooming.database.DatabaseConnection;

/**
 * ShoppingCart Model - Represents a customer's shopping cart
 * Each customer has one active cart
 */
public class ShoppingCart {
    
    // ==================== PROPERTIES ====================
    private int cartID;
    private int customerID;
    private LocalDateTime dateCreated;
    private LocalDateTime dateModified;
    
    // ==================== CONSTRUCTORS ====================
    
    public ShoppingCart() {
    }
    
    public ShoppingCart(int customerID) {
        this.customerID = customerID;
        this.dateCreated = LocalDateTime.now();
    }
    
    // ==================== GETTERS & SETTERS ====================
    
    public int getCartID() {
        return cartID;
    }
    
    public void setCartID(int cartID) {
        this.cartID = cartID;
    }
    
    public int getCustomerID() {
        return customerID;
    }
    
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }
    
    public LocalDateTime getDateCreated() {
        return dateCreated;
    }
    
    public void setDateCreated(LocalDateTime dateCreated) {
        this.dateCreated = dateCreated;
    }
    
    public LocalDateTime getDateModified() {
        return dateModified;
    }
    
    public void setDateModified(LocalDateTime dateModified) {
        this.dateModified = dateModified;
    }
    
    // ==================== VALIDATION METHODS ====================
    
    public boolean isValid() {
        return customerID > 0;
    }
    
    // ==================== DATABASE METHODS ====================
    
    public boolean save() {
        if (!isValid()) {
            System.out.println("Invalid cart data");
            return false;
        }
        
        String sql = "INSERT INTO ShoppingCart (customerID, dateCreated) VALUES (?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, customerID);
            stmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    this.cartID = rs.getInt(1);
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.out.println("Error saving cart: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean update() {
        if (!isValid() || cartID == 0) {
            return false;
        }
        
        String sql = "UPDATE ShoppingCart SET dateModified=? WHERE cartID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(2, cartID);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error updating cart: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean delete() {
        if (cartID == 0) {
            return false;
        }
        
        String sql = "DELETE FROM ShoppingCart WHERE cartID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, cartID);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Error deleting cart: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Clear all items from the cart
     */
    public boolean clearCart() {
        String sql = "DELETE FROM CartItem WHERE cartID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, cartID);
            stmt.executeUpdate();
            return true;
            
        } catch (SQLException e) {
            System.out.println("Error clearing cart: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // ==================== STATIC FINDER METHODS ====================
    
    public static ShoppingCart findByID(int cartID) {
        String sql = "SELECT * FROM ShoppingCart WHERE cartID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, cartID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractCartFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding cart: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Gets or creates a cart for a customer
     */
    public static ShoppingCart getOrCreateCart(int customerID) {
        ShoppingCart cart = findByCustomerID(customerID);
        
        if (cart == null) {
            cart = new ShoppingCart(customerID);
            cart.save();
        }
        
        return cart;
    }
    
    /**
     * Finds a cart by customer ID
     */
    public static ShoppingCart findByCustomerID(int customerID) {
        String sql = "SELECT * FROM ShoppingCart WHERE customerID=?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, customerID);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractCartFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.out.println("Error finding cart by customer: " + e.getMessage());
        }
        
        return null;
    }
    
    // ==================== HELPER METHODS ====================
    
    private static ShoppingCart extractCartFromResultSet(ResultSet rs) throws SQLException {
        ShoppingCart cart = new ShoppingCart();
        cart.setCartID(rs.getInt("cartID"));
        cart.setCustomerID(rs.getInt("customerID"));
        
        Timestamp created = rs.getTimestamp("dateCreated");
        if (created != null) {
            cart.setDateCreated(created.toLocalDateTime());
        }
        
        Timestamp modified = rs.getTimestamp("dateModified");
        if (modified != null) {
            cart.setDateModified(modified.toLocalDateTime());
        }
        
        return cart;
    }
    
    @Override
    public String toString() {
        return "ShoppingCart{" +
                "cartID=" + cartID +
                ", customerID=" + customerID +
                ", dateCreated=" + dateCreated +
                '}';
    }
}
