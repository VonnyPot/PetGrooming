package Business;

import java.io.IOException;

import jakarta.servlet.*;

/**
 * CustomerLoginServlet
 * Reads ID and Password from CustomerLogin.jsp and forwards the user
 * to either Customer.jsp or LoginError.jsp
 */
@WebServlet("/loginservlet")
public class CustomerLoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleLogin(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleLogin(request, response);
    }

    private void handleLogin(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        String pw = request.getParameter("password");

        if (id == null || pw == null || id.isEmpty() || pw.isEmpty()) {
            forward(request, response, "LoginError.jsp");
            return;
        }

        try {
            Customer c1 = new Customer();
            c1.selectDB(id);

            if (!c1.getCustID().isEmpty()
                    && c1.getCustID().equals(id)
                    && c1.getPassword().equals(pw)) {

                HttpSession session = request.getSession(true);
                session.setAttribute("c1", c1);

                forward(request, response, "Customer.jsp");
                return;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        forward(request, response, "LoginError.jsp");
    }

    private void forward(HttpServletRequest request, HttpServletResponse response, String page)
            throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher(page);
        rd.forward(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Handles customer login";
    }
}