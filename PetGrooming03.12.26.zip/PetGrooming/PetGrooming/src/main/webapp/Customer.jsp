<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Pet Services Booking</title>

    <style>

        body{
            margin:0;
            font-family: Arial, Helvetica, sans-serif;
            background:#f4f4f4;
        }

        //*Hero Section*//

        .hero{
            height:500px;
            background-image: url("Background.jpg");
            background-size:cover;
            background-position:center;
            display:flex;
            justify-content:center;
            align-items:center;
            text-align:center;
            color:white;
        }

        .hero h1{
            font-size:50px;
            margin-bottom:20px;
        }

        .btn{
            background:cornflowerblue;
            color:white;
            padding:15px 35px;
            border:none;
            border-radius:30px;
            font-size:18px;
            cursor:pointer;
            text-decoration:none;
        }

        .btn:hover{
            background:lightblue;
        }



        .info{
            background:white;
            padding:40px;
            display:flex;
            justify-content:space-around;
            flex-wrap:wrap;
        }

        .hours, .contact{
            width:300px;
        }

        h2{
            color:#333;
        }

        .gallery{
            display:flex;
            justify-content:center;
            gap:20px;
            padding:30px;
            background:#f9f9f9;
        }

        .gallery img{
            width:150px;
            height:120px;
            object-fit:cover;
            border-radius:10px;
        }

    </style>
</head>

<body>



<div class="hero">

    <div>
        <h1>Pet Services login </h1>

        <a href="Customerlogin.jsp" class="btn">Login</a>
    </div>

</div>




<div class="info">

    <div class="hours">

        <h2>Opening Hours</h2>

        <p>Mon - Fri : 9 AM - 8 PM</p>
        <p>Saturday : 9 AM - 5 PM</p>
        <p>Sunday : Closed</p>

    </div>


    <div class="contact">

        <h2>Contact Us</h2>

        <p>📞 +1 999-999-9999</p>
        <p>✉ petgroom@email.com</p>
        <p>📍 123 Pet Street, Atlanta, GA</p>

    </div>

</div>




<div class="gallery">

    <img src="cat store.jpg">
    <img src="cat-adoption-header.png">
    <img src="pet dog.jpg">
    <img src="Store-dogs.jpg">

</div>

</body>
</html>