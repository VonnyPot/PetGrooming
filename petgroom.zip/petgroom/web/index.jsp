<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Grooming</title>
    
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>
    <div class="main-container">
        <div class="header">
            <h1>Welcome to Pet Grooming</h1>
        </div>
        
        <div class="image-container">
            <img src="images/CatGroomCropped.jpg" alt="Pet grooming cropped" class="pet-image">
        </div>
               
        <div class="links-container">
            <a href="Customerlogin.jsp">Customer Login</a>
            <a href="Adminlogin.jsp">Administrator Login</a>
        </div>
         
        <!--<a href="hello-servlet">Hello Servlet</a>-->
    </div>
</body>
</html>